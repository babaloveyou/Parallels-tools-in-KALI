#define LINUX_PACKAGE_ID " Debian 4.15.11-1kali1"
