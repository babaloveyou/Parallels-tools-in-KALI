#define UTS_RELEASE "4.15.0-kali2-amd64"
